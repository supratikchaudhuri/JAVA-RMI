import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

/**
 * Server which is used to bind remote methods to the rmi registry and allow remote invocation by the client.
 */
public class Server {
  public static void main (String[] args) {

    try {
      if (args.length != 1 || Integer.parseInt(args[0]) > 65535) {
        throw new IllegalArgumentException("Invalid arguments. " +
                "Please provide valid PORT number (0-65535) and start again.");
      }

      String PORT = args[0];
      RemoteMethodInterface rmi = new MapMethods();
      LocateRegistry.createRegistry(Integer.parseInt(PORT));
      Naming.rebind("rmi://localhost:" + PORT + "/MapMethods", rmi);
      System.out.println("Server started");

    } catch (Exception e) {
      System.out.println("Error: " + e);
    }
  }
}
