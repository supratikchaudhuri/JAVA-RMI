import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.rmi.server.UnicastRemoteObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

/**
 * Implementation class of the `RemoteMethodInterface` class.
 */
public class MapMethods extends UnicastRemoteObject implements RemoteMethodInterface {
  static Properties prop;
  static OutputStream writer;
  static InputStream reader;
  protected MapMethods() throws IOException {
    super();

    prop = new Properties();
    reader = new FileInputStream("map.properties");
    prop.load(reader);
    writer = new FileOutputStream("map.properties", false);
    prop.store(writer, null);
    // automatically populate 5 key value pairs
    addToMap("hello", "world");
    addToMap("MS", "Computer Science");
    addToMap("CS6650", "Building Scalable Distributed System");
    addToMap("Firstname Lastname", "John Doe");
    addToMap("BTC", "Bitcoin");

  }

  @Override
  public synchronized String addToMap(String key, String value) throws IOException {
    prop.setProperty(key, value);
    prop.store(writer, null);
    return getTimeStamp() + "Inserted key \"" + key + "\" with value \"" + value + "\"";
  }

  @Override
  public synchronized String getFromMap(String key) throws InterruptedException {
    Thread.sleep(5000);
    String value = prop.getProperty(key);
    return getTimeStamp() + (value == null  || value.equals("~null~")?
            "No value found for key \"" + key + "\"" : "Key: \"" + key + "\" ,Value: \"" + value + "\"");
  }

  @Override
  public synchronized String deleteFroMap(String key) throws IOException {
    String res = "";
    if(prop.containsKey(key)) {
      addToMap(key, "~null~");
      prop.remove(key);
      prop.store(writer, null);
      res = "Deleted key \"" + key + "\"";
    }
    else {
      res = "Key not found.";
    }
    return getTimeStamp() + res;
  }

  private static String getTimeStamp() {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    return "[Time: " + sdf.format(new Date()) + "] ";
  }
}


